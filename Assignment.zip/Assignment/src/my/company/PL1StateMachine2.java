/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.company;

import com.ttsnetwork.modules.standard.BoxUtils;
import com.ttsnetwork.modules.standard.IConveyorCommands;
import com.ttsnetwork.modules.standard.IRobotCommands;
import com.ttsnetwork.modules.standard.ISensorProvider;
import com.ttsnetwork.modules.standard.SimpleStateVar;
import com.ttsnetwork.modules.standard.StateMachine;
import com.ttsnetwork.modulespack.conveyors.ConveyorBox;
import com.ttsnetwork.modulespack.conveyors.SensorCatch;

/**
 *
 * @author 24760
 */
public class PL1StateMachine2 extends StateMachine {

    double VROB = 700;

    ISensorProvider cA3Sen;

    IRobotCommands r3Cmd;

    IConveyorCommands cACmd, cD1Cmd, cD2Cmd;

    ConveyorBox boxOnA;

    SimpleStateVar partA_3 = new SimpleStateVar();

    SimpleStateVar move2D1Finished = new SimpleStateVar();
    SimpleStateVar move2D2Finished = new SimpleStateVar();

    @Override
    public void onInit() {
        cA3Sen = useSkill(ISensorProvider.class, "CA");

        cACmd = useSkill(IConveyorCommands.class, "CA");
        cD1Cmd = useSkill(IConveyorCommands.class, "CD1");
        cD2Cmd = useSkill(IConveyorCommands.class, "CD2");

        r3Cmd = useSkill(IRobotCommands.class, "R3");

        cA3Sen.registerOnSensors(this::sensor5, "S_CA3");

    }

    @Override
    public void onStart() {
        switchState(102);
    }

    void sensor5(SensorCatch sc) {
        schedule.startSerial();
        cACmd.lock(sc.box);
        setVar(partA_3, sc.box);
        schedule.end();
    }

    public void state_102() {
        if (partA_3.read() != null) {
            boxOnA = partA_3.readAndForget();
            switchState(202);
        }
    }

    public void state_202() {
        String variant = boxOnA.entity.getProperty("variant");

        switch (variant) {
            case "V1":
            case "V2": {
                switchState(302);
            }
            break;
            case "V3": {
                switchState(1302);
            }
            break;
        }

    }

    // 302,303 --> V1,V2
    public void state_302() {
        executeMoveProcess(boxOnA, "CD1.FD12", move2D1Finished);
        switchState(303);

    }

    public void state_303() {
        if (move2D1Finished.readBoolean()) {
            move2D1Finished.write(false);
            switchState(102);
        }
    }

    // 1302,1303 --> V3
    public void state_1302() {
        executeMoveProcess(boxOnA, "CD2.FD22", move2D2Finished);
        switchState(1303);

    }

    public void state_1303() {
        if (move2D2Finished.readBoolean()) {
            move2D2Finished.write(false);
            switchState(102);
        }
    }

    void executeMoveProcess(ConveyorBox box, String targetFrame, SimpleStateVar moveFinishedVar) {
        schedule.startSerial();
        {
            r3Cmd.moveLinear(driver.getFrameTransform("CA.FA"), VROB);
            r3Cmd.moveLinear(BoxUtils.targetOffset(box, 0, 0, BoxUtils.zSize(box) * 3, 0, 0, 0), VROB);
            r3Cmd.pick(box.entity);
            cACmd.remove(box);

            r3Cmd.moveLinear(driver.getFrameTransform("CA.FA"), VROB);
            r3Cmd.moveLinear(driver.getFrameTransform(targetFrame), VROB);
            r3Cmd.release();
            r3Cmd.home();

            cACmd.remove(box);

            switch (targetFrame) {
                case "CD1.FD12": {
                    cD1Cmd.insert(box);
                }
                break;
                case "CD2.FD22": {
                    cD2Cmd.insert(box);
                }
            }

            setVar(moveFinishedVar, true);
        }
        schedule.end();
    }
}
