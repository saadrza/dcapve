/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.company;

import com.ttsnetwork.modules.standard.BoxUtils;
import com.ttsnetwork.modules.standard.IConveyorCommands;
import com.ttsnetwork.modules.standard.IRobotCommands;
import com.ttsnetwork.modules.standard.ISensorProvider;
import com.ttsnetwork.modules.standard.ISource;
import com.ttsnetwork.modules.standard.ProgrammableLogics;
import com.ttsnetwork.modulespack.conveyors.ConveyorBox;
import com.ttsnetwork.modulespack.conveyors.SensorCatch;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author 24760
 */
public class PL1 extends ProgrammableLogics {

    double VROB = 700; // Velocity of the robotic arm for linear movements

    // Sensor interface variables
    ISensorProvider cA1Sen;
    ISensorProvider cA2Sen;
    ISensorProvider cA3Sen;
    ISensorProvider cBSen;
    ISensorProvider cCSen;

    // Source material creation variables
    ISource srcS2;
    ISource srcS3;

    // Robot command variables
    IRobotCommands r1Cmd;
    IRobotCommands r2Cmd;
    IRobotCommands r3Cmd;

    // Conveyor command variables
    IConveyorCommands cACmd;
    IConveyorCommands cBCmd;
    IConveyorCommands cCCmd;
    IConveyorCommands cD1Cmd;
    IConveyorCommands cD2Cmd;

    // Variables to store current boxes on conveyors
    ConveyorBox boxOnA;
    ConveyorBox boxOnB;
    ConveyorBox boxOnC;

    // Maps to track the required and assembled component counts for each variant
    Map<String, Integer> requiredComponents = new HashMap<>();
    Map<String, Integer> assembledComponents = new HashMap<>();

    // Array representing the production sequence: {2 V1, 1 V2, 2 V3}
    private final int[] productionSequence = {1, 1, 2, 3, 3};
    private int sequenceIndex = 0; // Current sequence index
    private int variantCount = 0; // Track count of the same variant

    // Flags to mark if variants are fully assembled
    private boolean isV1Ready = false;
    private boolean isV2Ready = false;
    private boolean isV3Ready = false;

    // Constructor initializing the required component counts for each variant
    public PL1() {
        requiredComponents.put("V1", 2);
        requiredComponents.put("V2", 2); // V2 needs 1 B and 1 C
        requiredComponents.put("V3", 2);
        assembledComponents.put("V1", 0);
        assembledComponents.put("V2", 0);
        assembledComponents.put("V3", 0);
    }

    @Override
    public void onStart() {
        
    }

    @Override
    public void onInit() {
        // Initialize command and sensor interfaces for each conveyor belt and robot
        cA1Sen = useSkill(ISensorProvider.class, "CA");
        cA2Sen = useSkill(ISensorProvider.class, "CA");
        cA3Sen = useSkill(ISensorProvider.class, "CA");
        cBSen = useSkill(ISensorProvider.class, "CB");
        cCSen = useSkill(ISensorProvider.class, "CC");

        cACmd = useSkill(IConveyorCommands.class, "CA");
        cBCmd = useSkill(IConveyorCommands.class, "CB");
        cCCmd = useSkill(IConveyorCommands.class, "CC");
        cD1Cmd = useSkill(IConveyorCommands.class, "CD1");
        cD2Cmd = useSkill(IConveyorCommands.class, "CD2");

        srcS2 = useSkill(ISource.class, "S2");
        srcS3 = useSkill(ISource.class, "S3");

        r1Cmd = useSkill(IRobotCommands.class, "R1");
        r2Cmd = useSkill(IRobotCommands.class, "R2");
        r3Cmd = useSkill(IRobotCommands.class, "R3");

        // Register sensors to trigger the appropriate methods when boxes arrive
        cA1Sen.registerOnSensors(this::sensor1, "S_CA1");
        // cA2Sen.registerOnSensors(this::sensor2, "S_CA2");
        cA3Sen.registerOnSensors(this::sensor3, "S_CA3");
        cBSen.registerOnSensors(this::sensor4, "S_CB");
        cCSen.registerOnSensors(this::sensor5, "S_CC");
    }

    /**
     * Handles the arrival of a box at the sensor on conveyor A. Locks the box
     * and sets its variant based on the current production sequence.
     */
    void sensor1(SensorCatch sc) {
        boxOnA = sc.box; // The box used to identify which variant it belongs to.
        schedule.startSerial();
        cACmd.lock(sc.box); // Lock the box on conveyor A

        if (sequenceIndex >= productionSequence.length) {
            sequenceIndex = 0; // Restart the sequence if it ends
        }

        int variantToProduce = productionSequence[sequenceIndex];
        // Track the count of the same variant
        variantCount++;
        if (variantCount > (variantToProduce == 2 ? 1 : 2)) { // Produce 1 for V2, 2 for V1 and V3
            variantCount = 1; // Reset variant count
            sequenceIndex++; // Move to the next variant
        }

        // Set the variant property of the product
        String variantProperty = "V" + variantToProduce;
        sc.box.entity.setProperty("variant", variantProperty);
        // Output the product number and variant type
        System.out.println("Product " + (sequenceIndex + 1) + " is variant " + variantProperty);

        // Trigger appropriate component creation based on the variant to produce
        switch (variantToProduce) {
            case 1: // V1 production cycle: A + 2 B
                srcS2.create(null); // Trigger S2 to produce a B component
                schedule.waitTime(1000); // Delay to ensure two are created
                srcS2.create(null); // Trigger S2 to produce another B component
                break;
            case 2: // V2 production cycle: A + B + C
                srcS2.create(null);
                schedule.waitTime(1000);
                srcS3.create(null);
                break;
            case 3: // V3 production cycle: A + 2 C
                srcS3.create(null);
                schedule.waitTime(1000);
                srcS3.create(null);
                break;
        }

        schedule.end();
    }

    // void sensor2(SensorCatch sc) { }
    
    /**
     * Handles the arrival of a box at the sensor on conveyor A3, moving it to
     * the appropriate destination. Uses the robot R3 to pick and move the box.
     */
    void sensor3(SensorCatch sc) {
        schedule.startSerial();    // Start serial task scheduling
        cACmd.lock(sc.box);
        String variant = sc.box.entity.getProperty("variant"); // Retrieve the product variant information
        r3Cmd.moveLinear(driver.getFrameTransform("CA.FA"), VROB); // Move to V1, V2, V3 positions
        r3Cmd.moveLinear(BoxUtils.targetTop(sc.box), VROB); // Move to the top of the box
        r3Cmd.pick(sc.box.entity); // Pick up the box

        // Move to the appropriate destination based on the variant
        switch (variant) {
            case "V1":
            case "V2":
                r3Cmd.moveLinear(driver.getFrameTransform("CD1.FD1"), VROB); // Move to V1, V2 positions
                cACmd.remove(boxOnA);
                cD1Cmd.insert(boxOnA);
                break;
            case "V3":
                r3Cmd.moveLinear(driver.getFrameTransform("CD2.FD2"), VROB); // Move to V3 position
                cACmd.remove(boxOnA);
                cD2Cmd.insert(boxOnA);
                break;
        }
        r3Cmd.home(); 
        cACmd.release(sc.box);
        schedule.end(); 
    }

    /**
     * Handles the arrival of a box at the sensor on conveyor B. Triggers the
     * assembly process specific to conveyor B.
     */
    void sensor4(SensorCatch sc) {
        boxOnB = sc.box;
        executeAssemblyProcess(sc, "CB.FB", boxOnB, cBCmd); // Lock conveyor B
    }

    /**
     * Handles the arrival of a box at the sensor on conveyor C. Triggers the
     * assembly process specific to conveyor C.
     */
    void sensor5(SensorCatch sc) {
        boxOnC = sc.box;
        executeAssemblyProcess(sc, "CC.FC", boxOnC, cCCmd); // Lock conveyor C
    }

    /**
     * Generic function that handles assembly processes for conveyors B and C.
     * Moves the robot to pick up a component and attach it to the box on
     * conveyor A.
     *
     * @param sc Sensor catch event
     * @param frameTransform Frame transform name to move to
     * @param box Box to attach components to
     * @param conveyorCmd Conveyor commands to use
     */
    void executeAssemblyProcess(SensorCatch sc, String frameTransform, ConveyorBox box, IConveyorCommands conveyorCmd) {
        box = sc.box;
        schedule.startSerial();
        conveyorCmd.lock(box); // Lock the conveyor using the passed conveyorCmd
        r1Cmd.moveLinear(driver.getFrameTransform(frameTransform), VROB); // Move to the frame
        r1Cmd.moveLinear(BoxUtils.targetTop(sc.box), VROB); // Move to the top of the box
        r1Cmd.pick(sc.box.entity); // Pick up the component
        conveyorCmd.remove(sc.box); // Remove the component from the conveyor

        // Attach the component to the box on conveyor A if it's a V1 or V2 variant
        if ("V1".equals(boxOnA.entity.getProperty("variant")) || "V2".equals(boxOnA.entity.getProperty("variant"))) {
            r1Cmd.moveLinear(driver.getFrameTransform(frameTransform), VROB);
            r1Cmd.moveLinear(BoxUtils.targetOffset(boxOnA, 0, 0, 400, 0, 0, 0), VROB); // Position correctly
            r1Cmd.moveLinear(BoxUtils.targetTop(boxOnA), VROB); // Move to the top of box A
            schedule.attach(sc.box.entity, boxOnA.entity); // Attach the component
            markVariantReady(boxOnA.entity.getProperty("variant")); // Mark the variant as ready
        }
        r1Cmd.home(); // Return to the original position
        schedule.end();
        manageAssemblyProcess(); // Manage further assembly processes
    }

    /**
     * Mark the given variant as ready if it has been fully assembled. Resets
     * the component count once the variant is ready.
     *
     * @param variant The variant to mark as ready
     */
    void markVariantReady(String variant) {
        int count = assembledComponents.getOrDefault(variant, 0) + 1;
        assembledComponents.put(variant, count);

        // Check if all components required for the variant have been assembled
        if (count >= requiredComponents.get(variant)) {
            switch (variant) {
                case "V1":
                    isV1Ready = true;
                    break;
                case "V2":
                    isV2Ready = true;
                    break;
                case "V3":
                    isV3Ready = true;
                    break;
            }
            assembledComponents.put(variant, 0); // Reset component count after marking ready
        }
    }

    /**
     * Manage the assembly process by determining if a product is ready to be
     * released or if additional assembly steps are needed.
     *
     * If ready, the product is released and assembly continues for the same or
     * next variant.
     */
    void manageAssemblyProcess() {
        String variant = boxOnA.entity.getProperty("variant");

        // Release the box if the variant is ready, otherwise continue the assembly process
        if ((isV1Ready && "V1".equals(variant)) || (isV2Ready && "V2".equals(variant)) || (isV3Ready && "V3".equals(variant))) {
            cACmd.release(boxOnA);
            System.out.println("Released: " + variant);
            resetVariantReadiness();
            continueAssembly(variant);
        } else {
            continueAssembly(variant);
        }
    }

    /**
     * Reset the readiness status of all variants to not ready.
     */
    void resetVariantReadiness() {
        isV1Ready = false;
        isV2Ready = false;
        isV3Ready = false;
    }

    /**
     * Continue the assembly process for the given variant.
     *
     * @param variant The variant to continue assembly for
     */
    void continueAssembly(String variant) {
        switch (variant) {
            case "V1":
                if (!isV1Ready) {
                    continueBAssembly(2); // V1 requires 2 B components
                }
                break;
            case "V2":
                if (!isV2Ready) {
                    continueBAssembly(1); // V2 requires 1 B component
                    continueCAssembly(1); // V2 requires 1 C component
                }
                break;
            case "V3":
                if (!isV3Ready) {
                    continueCAssembly(2); // V3 requires 2 C components
                }
                break;
        }
    }

    /**
     * Continue the assembly process for B components.
     *
     * @param quantity Number of B components to assemble
     */
    void continueBAssembly(int quantity) {
        for (int i = 0; i < quantity; i++) {
            r1Cmd.moveLinear(driver.getFrameTransform("CB.FB"), VROB);
            r1Cmd.moveLinear(BoxUtils.targetTop(boxOnB), VROB);
            r1Cmd.pick(boxOnB.entity);
            cBCmd.remove(boxOnB);
            r1Cmd.moveLinear(BoxUtils.targetOffset(boxOnA, 0, 0, 400, 0, 0, 0), VROB);
            r1Cmd.moveLinear(BoxUtils.targetTop(boxOnA), VROB);
            schedule.attach(boxOnB.entity, boxOnA.entity);
            r1Cmd.home();
        }
    }

    /**
     * Continue the assembly process for C components.
     *
     * @param quantity Number of C components to assemble
     */
    void continueCAssembly(int quantity) {
        for (int i = 0; i < quantity; i++) {
            r1Cmd.moveLinear(driver.getFrameTransform("CC.FC"), VROB);
            r1Cmd.moveLinear(BoxUtils.targetTop(boxOnC), VROB);
            r1Cmd.pick(boxOnC.entity);
            cCCmd.remove(boxOnC);
            r1Cmd.moveLinear(BoxUtils.targetOffset(boxOnA, 0, 0, 400, 0, 0, 0), VROB);
            r1Cmd.moveLinear(BoxUtils.targetTop(boxOnA), VROB);
            schedule.attach(boxOnC.entity, boxOnA.entity);
            r1Cmd.home();
        }
    }
    
    // BoxUtils.targetOffset(sc.box, BoxUtils.xSize(sc.box)*0.5, VROB, VROB, VROB, VROB, VROB)
}
