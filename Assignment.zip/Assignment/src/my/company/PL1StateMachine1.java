/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.company;

import com.ttsnetwork.modules.standard.BoxUtils;
import com.ttsnetwork.modules.standard.IConveyorCommands;
import com.ttsnetwork.modules.standard.IRobotCommands;
import com.ttsnetwork.modules.standard.ISensorProvider;
import com.ttsnetwork.modules.standard.SimpleStateVar;
import com.ttsnetwork.modules.standard.StateMachine;
import com.ttsnetwork.modulespack.conveyors.ConveyorBox;
import com.ttsnetwork.modulespack.conveyors.SensorCatch;

/**
 *
 * @author 24760
 */
public class PL1StateMachine1 extends StateMachine {

    double VROB = 700;
    ISensorProvider cA2Sen;

    IRobotCommands r2Cmd;

    IConveyorCommands cACmd;

    ConveyorBox boxOnA;

    SimpleStateVar partA_2 = new SimpleStateVar();

    SimpleStateVar weldingFinished = new SimpleStateVar();

    @Override
    public void onInit() {
        cA2Sen = useSkill(ISensorProvider.class, "CA");

        cACmd = useSkill(IConveyorCommands.class, "CA");

        r2Cmd = useSkill(IRobotCommands.class, "R2");

        cA2Sen.registerOnSensors(this::sensor4, "S_CA2");
    }

    @Override
    public void onStart() {
        switchState(101);
    }

    void sensor4(SensorCatch sc) {
        schedule.startSerial();
        cACmd.lock(sc.box);
        setVar(partA_2, sc.box);
        schedule.end();
    }

    public void state_101() {
        if (partA_2.read() != null) {
            boxOnA = partA_2.readAndForget();
            switchState(201);
        }
    }

    public void state_201() {
        excuteWelding();
        switchState(301);
    }

    public void state_301() {
        if (weldingFinished.readBoolean()) {
            weldingFinished.write(false);
            switchState(101);
        }
    }

    void excuteWelding() {
        schedule.startSerial();
        {
            r2Cmd.moveLinear(driver.getFrameTransform("CA.FW"), VROB);
            // First Box
            ConveyorBox box1 = boxOnA.entity.getProperty("boxU1");
            weldingMove(box1);

            // Second Box
            ConveyorBox box2 = boxOnA.entity.getProperty("boxU2");
            weldingMove(box2);

            r2Cmd.home();
            cACmd.release(boxOnA);
            setVar(weldingFinished, true);
        }
        schedule.end();
    }

    void weldingMove(ConveyorBox box) {

        r2Cmd.moveLinear(BoxUtils.targetOffset(box, BoxUtils.xSize(box) / 2, BoxUtils.ySize(box) / 2, 0, 0, 45, 0), VROB);
        r2Cmd.moveLinear(BoxUtils.targetOffset(box, BoxUtils.xSize(box) / 2, -BoxUtils.ySize(box) / 2, 0, 0, 45, 0), VROB);

        r2Cmd.moveLinear(BoxUtils.targetOffset(box, BoxUtils.xSize(box) / 2, -BoxUtils.ySize(box) / 2, 0, 45, 0, -90), VROB);
        r2Cmd.moveLinear(BoxUtils.targetOffset(box, -BoxUtils.xSize(box) / 2, -BoxUtils.ySize(box) / 2, 0, 45, 0, -90), VROB);

        r2Cmd.moveLinear(BoxUtils.targetOffset(box, -BoxUtils.xSize(box) / 2, -BoxUtils.ySize(box) / 2, 0, 0, -45, 180), VROB);
        r2Cmd.moveLinear(BoxUtils.targetOffset(box, -BoxUtils.xSize(box) / 2, BoxUtils.ySize(box) / 2, 0, 0, -45, 180), VROB);

        r2Cmd.moveLinear(BoxUtils.targetOffset(box, -BoxUtils.xSize(box) / 2, BoxUtils.ySize(box) / 2, 0, -45, 0, 90), VROB);
        r2Cmd.moveLinear(BoxUtils.targetOffset(box, BoxUtils.xSize(box) / 2, BoxUtils.ySize(box) / 2, 0, -45, 0, 90), VROB);

        r2Cmd.moveLinear(driver.getFrameTransform("CA.FW"), VROB);
    }

}
