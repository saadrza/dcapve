/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.company;

import com.ttsnetwork.modules.standard.BoxUtils;
import com.ttsnetwork.modules.standard.IConveyorCommands;
import com.ttsnetwork.modules.standard.IRobotCommands;
import com.ttsnetwork.modules.standard.ISensorProvider;
import com.ttsnetwork.modules.standard.SimpleStateVar;
import com.ttsnetwork.modules.standard.StateMachine;
import com.ttsnetwork.modulespack.conveyors.ConveyorBox;
import com.ttsnetwork.modulespack.conveyors.SensorCatch;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author 24760
 */
public class PL1StateMachine extends StateMachine {

    double VROB = 700;

    ISensorProvider cA1Sen, cBSen, cCSen;

    IRobotCommands r1Cmd;

    IConveyorCommands cACmd, cBCmd, cCCmd;

    ConveyorBox boxOnA, boxOnB, boxOnC;

    SimpleStateVar partA = new SimpleStateVar();
    SimpleStateVar partB = new SimpleStateVar();
    SimpleStateVar partC = new SimpleStateVar();

    Map<String, Integer> requiredComponents = new HashMap<>();
    Map<String, Integer> assembledComponents = new HashMap<>();

    // Array representing the production sequence: {2 V1, 1 V2, 2 V3}
    private final int[] productionSequence = {1, 1, 2, 3, 3};
    private int sequenceIndex = 0;

    SimpleStateVar asmBFinished = new SimpleStateVar();
    SimpleStateVar asmCFinished = new SimpleStateVar();

    SimpleStateVar V1Height = new SimpleStateVar();
    SimpleStateVar V2Height = new SimpleStateVar();
    SimpleStateVar V3Height = new SimpleStateVar();

    public PL1StateMachine() {
        requiredComponents.put("V1", 2);
        requiredComponents.put("V2", 2);
        requiredComponents.put("V3", 2);
        assembledComponents.put("V1", 0);
        assembledComponents.put("V2", 0);
        assembledComponents.put("V3", 0);
    }

    @Override
    public void onInit() {

        cA1Sen = useSkill(ISensorProvider.class, "CA");
        cBSen = useSkill(ISensorProvider.class, "CB");
        cCSen = useSkill(ISensorProvider.class, "CC");

        cACmd = useSkill(IConveyorCommands.class, "CA");
        cBCmd = useSkill(IConveyorCommands.class, "CB");
        cCCmd = useSkill(IConveyorCommands.class, "CC");

        r1Cmd = useSkill(IRobotCommands.class, "R1");

        // Register sensors to trigger the appropriate methods when boxes arrive
        cA1Sen.registerOnSensors(this::sensor1, "S_CA1");
        cBSen.registerOnSensors(this::sensor2, "S_CB");
        cCSen.registerOnSensors(this::sensor3, "S_CC");

    }

    @Override
    public void onStart() {
        switchState(100);
    }

    void sensor1(SensorCatch sc) {
        schedule.startSerial();
        cACmd.lock(sc.box);
        setVar(partA, sc.box);
        schedule.end();
    }

    void sensor2(SensorCatch sc) {
        schedule.startSerial();
        cBCmd.lock(sc.box);
        setVar(partB, sc.box);
        schedule.end();
    }

    void sensor3(SensorCatch sc) {
        schedule.startSerial();
        cCCmd.lock(sc.box);
        setVar(partC, sc.box);
        schedule.end();
    }

    public void state_100() {
        if (partA.read() != null) {
            boxOnA = partA.readAndForget();
            switchState(200);
        }
    }

    public void state_200() {

        int variantToProduce = productionSequence[sequenceIndex % productionSequence.length];
        // Track the count of the same variant
        sequenceIndex++; // Move to the next variant
        // Set the variant property of the product
        String variantProperty = "V" + variantToProduce;
        boxOnA.entity.setProperty("variant", variantProperty);
        // Output the product number and variant type
        String variant = boxOnA.entity.getProperty("variant");
        System.out.println("Product " + sequenceIndex + " is variant " + variant);

        switch (variant) {
            case "V1": {
                switchState(300);
            }
            break;
            case "V2": {
                switchState(1300);
            }
            break;
            case "V3": {
                switchState(2300);
            }
            break;
        }
    }

// 300,400,500,600,700 --> V1
    public void state_300() {
        if (partB.read() != null) {
            boxOnB = partB.readAndForget();
            switchState(400);

        }
    }

    public void state_400() {
        executeAssemblyProcess(boxOnA, "CB.FB", boxOnB, cBCmd, asmBFinished);
        switchState(500);
    }

    public void state_500() {
        if (asmBFinished.readBoolean() && partB.read() != null) {
            V1Height.write(true);
            asmBFinished.write(false);
            boxOnB = partB.readAndForget();
            switchState(600);

        }
    }

    public void state_600() {
        executeAssemblyProcess(boxOnA, "CB.FB", boxOnB, cBCmd, asmBFinished);
        switchState(700);
    }

    public void state_700() {
        if (asmBFinished.readBoolean()) {
            asmBFinished.write(false);
            V1Height.write(false);
            releaseBoxA();
            switchState(100);
        }
    }

    // 1300,1400,1500,1600,1700 --> V2
    public void state_1300() {
        if (partB.read() != null) {
            boxOnB = partB.readAndForget();
            switchState(1400);

        }
    }

    public void state_1400() {
        executeAssemblyProcess(boxOnA, "CB.FB", boxOnB, cBCmd, asmBFinished);
        switchState(1500);
    }

    public void state_1500() {
        if (asmBFinished.readBoolean() && partC.read() != null) {
            asmBFinished.write(false);
            V2Height.write(true);
            boxOnC = partC.readAndForget();
            switchState(1600);

        }
    }

    public void state_1600() {
        executeAssemblyProcess(boxOnA, "CC.FC", boxOnC, cCCmd, asmCFinished);
        switchState(1700);
    }

    public void state_1700() {
        if (asmCFinished.readBoolean()) {
            asmCFinished.write(false);
            V2Height.write(false);
            releaseBoxA();
            switchState(100);
        }
    }

    // 2300,2400,2500,2600,2700 --> V3
    public void state_2300() {
        if (partC.read() != null) {
            boxOnC = partC.readAndForget();
            switchState(2400);

        }
    }

    public void state_2400() {
        executeAssemblyProcess(boxOnA, "CC.FC", boxOnC, cCCmd, asmCFinished);
        switchState(2500);
    }

    public void state_2500() {
        if (asmCFinished.readBoolean() && partC.read() != null) {
            asmCFinished.write(false);
            V3Height.write(true);
            boxOnC = partC.readAndForget();
            switchState(2600);

        }
    }

    public void state_2600() {
        executeAssemblyProcess(boxOnA, "CC.FC", boxOnC, cCCmd, asmCFinished);
        switchState(2700);
    }

    public void state_2700() {
        if (asmCFinished.readBoolean()) {
            V3Height.write(false);
            asmCFinished.write(false);
            releaseBoxA();
            switchState(100);
        }
    }

    void executeAssemblyProcess(ConveyorBox box1, String frameTransform, ConveyorBox box2, IConveyorCommands conveyorCmd, SimpleStateVar asmFinishedVar) {
        schedule.startSerial();
        r1Cmd.moveLinear(driver.getFrameTransform(frameTransform), VROB);
        r1Cmd.moveLinear(BoxUtils.targetTop(box2), VROB);
        r1Cmd.pick(box2.entity);
        conveyorCmd.remove(box2);
        r1Cmd.moveLinear(driver.getFrameTransform(frameTransform), VROB);
        r1Cmd.moveLinear(BoxUtils.targetOffset(box1, 0, 0, 400, 0, 0, 0), VROB);
        if (V1Height.readBoolean() || V2Height.readBoolean() || V3Height.readBoolean()) {
            r1Cmd.moveLinear(BoxUtils.targetOffset(box1, 0, 0, BoxUtils.zSize(box2) * 3, 0, 0, 0), VROB);
            box1.entity.setProperty("boxU2", box2);
        } else {
            r1Cmd.move(BoxUtils.targetTop(box1), box2.cF, 1000L);
            box1.entity.setProperty("boxU1", box2);
        }
        r1Cmd.release();
        schedule.attach(box2.entity, box1.entity);
        r1Cmd.home();
        setVar(asmFinishedVar, true);
        schedule.end();
    }

    void releaseBoxA() {
        schedule.startSerial();
        cACmd.release(boxOnA);
        schedule.end();
    }
}
